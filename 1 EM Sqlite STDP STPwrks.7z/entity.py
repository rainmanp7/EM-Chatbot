import numpy as np
import random
import sqlite3
import logging
import json
from collections import defaultdict, deque

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

class Entity:
    def __init__(self, name, action_space, state_space, db_path='entity_memory.db', config_file='config.json'):
        self.name = name
        self.action_space = action_space
        self.state_space = state_space
        self.q_table = np.zeros((state_space, action_space))
        
        # Load configuration from file
        with open(config_file, 'r') as f:
            config = json.load(f)
        
        self.learning_rate = config.get('learning_rate', 0.1)
        self.discount_factor = config.get('discount_factor', 0.95)
        self.exploration_rate = config.get('exploration_rate', 1.0)
        self.exploration_decay = config.get('exploration_decay', 0.99)
        self.db_path = db_path
        self.math_understanding = defaultdict(float)
        
        # STDP parameters
        self.stdp_window = config.get('stdp_window', 10)
        self.stdp_history = deque(maxlen=self.stdp_window)
        self.stdp_ltp = config.get('stdp_ltp', 0.1)
        self.stdp_ltd = config.get('stdp_ltd', 0.05)
        
        # STP parameters
        self.stp_facilitation = config.get('stp_facilitation', 0.2)  # Facilitation strength
        self.stp_depression = config.get('stp_depression', 0.1)  # Depression strength
        self.stp_decay = config.get('stp_decay', 0.9)  # Decay rate for STP effects
        self.stp_effects = defaultdict(float)  # Tracks STP effects for each state-action pair
        
        self._init_db()
        self.load_q_table()
        self.load_math_understanding()

    def _init_db(self):
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS q_table (
                        subject TEXT,
                        state INTEGER,
                        action INTEGER,
                        value REAL,
                        PRIMARY KEY (subject, state, action)
                    )
                ''')
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS math_understanding (
                        subject TEXT PRIMARY KEY,
                        percentage REAL
                    )
                ''')
                conn.commit()
        except sqlite3.Error as e:
            logging.error(f"Database error: {e}")

    def load_math_understanding(self):
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute('SELECT subject, percentage FROM math_understanding')
                self.math_understanding = {subject: percentage for subject, percentage in cursor.fetchall()}
        except sqlite3.Error as e:
            logging.error(f"Database error: {e}")

    def save_math_understanding(self):
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.executemany('INSERT OR REPLACE INTO math_understanding (subject, percentage) VALUES (?, ?)',
                                   self.math_understanding.items())
                conn.commit()
        except sqlite3.Error as e:
            logging.error(f"Database error: {e}")

    def load_q_table(self):
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute('SELECT state, action, value FROM q_table WHERE subject = ?', (self.name,))
                for state, action, value in cursor.fetchall():
                    self.q_table[state, action] = value
        except sqlite3.Error as e:
            logging.error(f"Database error: {e}")

    def save_q_table(self):
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute('DELETE FROM q_table WHERE subject = ?', (self.name,))
                cursor.executemany('INSERT INTO q_table (subject, state, action, value) VALUES (?, ?, ?, ?)',
                                   [(self.name, state, action, self.q_table[state, action])
                                    for state in range(self.state_space) for action in range(self.action_space)])
                conn.commit()
        except sqlite3.Error as e:
            logging.error(f"Database error: {e}")

    def choose_action(self, state):
        # Apply STP effects to Q-values temporarily
        stp_adjusted_q_table = self.q_table.copy()
        for (s, a), effect in self.stp_effects.items():
            stp_adjusted_q_table[s, a] += effect
        
        # Choose action based on STP-adjusted Q-values
        return random.randint(0, self.action_space - 1) if random.random() < self.exploration_rate else np.argmax(stp_adjusted_q_table[state])

    def learn(self, state, action, reward, next_state):
        best_next_action = np.argmax(self.q_table[next_state])
        td_target = reward + self.discount_factor * self.q_table[next_state, best_next_action]
        td_error = td_target - self.q_table[state, action]

        # Update Q-value using Q-learning
        self.q_table[state, action] += self.learning_rate * td_error

        # STDP: Update Q-values based on temporal relationships
        for prev_state, prev_action, prev_time in self.stdp_history:
            if prev_state == state and prev_action == action:
                # Long-term potentiation (LTP): Pre-synaptic spike before post-synaptic spike
                self.q_table[prev_state, prev_action] += self.stdp_ltp * td_error
            else:
                # Long-term depression (LTD): Pre-synaptic spike after post-synaptic spike
                self.q_table[prev_state, prev_action] -= self.stdp_ltd * td_error

        # Add current state-action pair to STDP history
        self.stdp_history.append((state, action, len(self.stdp_history)))

        # STP: Update short-term plasticity effects
        self.stp_effects[(state, action)] += self.stp_facilitation  # Facilitation
        for (s, a) in self.stp_effects:
            if (s, a) != (state, action):
                self.stp_effects[(s, a)] -= self.stp_depression  # Depression
            self.stp_effects[(s, a)] *= self.stp_decay  # Decay STP effects over time

        self.save_q_table()

    def decay_exploration(self):
        self.exploration_rate = max(0.01, self.exploration_rate * self.exploration_decay)

    def __repr__(self):
        return f"Entity(name={self.name}, exploration_rate={self.exploration_rate})"