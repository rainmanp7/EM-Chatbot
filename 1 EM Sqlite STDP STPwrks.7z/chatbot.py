from entity import Entity
from environment import MathEnvironment
from train_entity import train_entity  # Import the train_entity function
import logging

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

def chatbot():
    state_space = 5  # Number of possible states
    action_space = 5  # Number of possible actions

    # Initialize the entity and environment
    entity = Entity("AI_Entity", action_space, state_space, config_file='config.json')
    env = MathEnvironment(state_space, action_space)

    try:
        # Load the math understanding percentages
        entity.load_math_understanding()

        # Debug: Print the loaded math understanding
        logging.debug("Debug: Loaded math understanding from database:")
        for subject, percentage in entity.math_understanding.items():
            logging.debug(f"- {subject}: {percentage:.2f}%")

        # Display current math understanding
        print("Chatbot is ready! Here's the current math understanding:")
        for subject, percentage in entity.math_understanding.items():
            print(f"- {subject}: {percentage:.2f}%")

        print("Type 'train <subject>' to start training or 'exit' to quit.")
        while True:
            try:
                user_input = input("You: ").strip().lower()
                if user_input.startswith('train'):
                    try:
                        subject = user_input.split()[1]  # Extract the subject
                        # Validate the subject
                        valid_subjects = ["counting", "addition", "subtraction", "multiplication", "division"]
                        if subject not in valid_subjects:
                            print(f"Invalid subject: {subject}. Valid subjects are: {', '.join(valid_subjects)}")
                            continue
                        print(f"Starting training on {subject}...")
                        train_entity(subject=subject, plot_rewards=False)  # Train without plotting
                        print(f"Training complete. Entity has learned {subject}.")
                    except IndexError:
                        print("Invalid command. Please specify a subject (e.g., 'train addition').")
                elif user_input == 'exit':
                    print("Exiting chatbot. Goodbye!")
                    break
                else:
                    print("Invalid command. Type 'train <subject>' to start training or 'exit' to quit.")
            except Exception as e:
                logging.error(f"An error occurred while processing your input: {e}")
                print("An error occurred while processing your input. Please try again or type 'exit' to quit.")
    except Exception as e:
        logging.error(f"An unexpected error occurred during chatbot initialization: {e}")
        print("An unexpected error occurred during chatbot initialization. The chatbot will now exit. Please check the logs for more details.")

if __name__ == "__main__":
    chatbot()