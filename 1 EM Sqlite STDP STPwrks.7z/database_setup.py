import sqlite3

def setup_database():
    db_path = "entity_memory.db"
    with sqlite3.connect(db_path) as conn:
        cursor = conn.cursor()
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS q_table (
            subject TEXT,
            state INTEGER,
            action INTEGER,
            value REAL,
            PRIMARY KEY (subject, state, action)
        )
        ''')
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS math_understanding (
            subject TEXT PRIMARY KEY,
            percentage REAL
        )
        ''')
        subjects = ["counting", "addition", "subtraction", "multiplication", "division"]
        cursor.executemany('''
        INSERT OR IGNORE INTO math_understanding (subject, percentage)
        VALUES (?, ?)
        ''', [(subject, 0.0) for subject in subjects])
        conn.commit()
    print("Database created successfully with the required schema and initial data.")

if __name__ == "__main__":
    setup_database()