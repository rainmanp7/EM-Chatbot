import random
import numpy as np

class MathEnvironment:
    def __init__(self, state_space, action_space):
        self.state_space = state_space
        self.action_space = action_space

    def generate_counting_problem(self):
        number = random.randint(1, 10)
        problem = f"What comes after {number}?"
        correct_answer = number + 1
        possible_answers = {correct_answer}
        while len(possible_answers) < self.action_space:
            random_answer = random.randint(1, 12)
            possible_answers.add(random_answer)
        possible_answers = list(possible_answers)
        np.random.shuffle(possible_answers)
        return problem, correct_answer, possible_answers

    def generate_math_problem(self, subject):
        num1 = random.randint(1, 10)
        num2 = random.randint(1, 10)
        if subject == "addition":
            problem = f"{num1} + {num2}"
            correct_answer = num1 + num2
            range_min, range_max = 2, 20
        elif subject == "subtraction":
            problem = f"{num1} - {num2}"
            correct_answer = num1 - num2
            range_min, range_max = -9, 10
        elif subject == "multiplication":
            problem = f"{num1} * {num2}"
            correct_answer = num1 * num2
            range_min, range_max = 1, 100
        elif subject == "division":
            num2 = random.randint(1, 10)
            problem = f"{num1} / {num2}"
            correct_answer = round(num1 / num2, 2)
            range_min, range_max = 0.1, 10
        else:
            raise ValueError(f"Unknown math subject: {subject}")

        possible_answers = {correct_answer}
        while len(possible_answers) < self.action_space:
            random_answer = round(np.random.uniform(range_min, range_max), 2)
            possible_answers.add(random_answer)
        possible_answers = list(possible_answers)
        np.random.shuffle(possible_answers)
        return problem, correct_answer, possible_answers

    def get_reward(self, chosen_answer, correct_answer):
        return 10 if chosen_answer == correct_answer else -1

    def reset(self):
        return 0

    def next_state(self, state, action):
        return (state + action) % self.state_space