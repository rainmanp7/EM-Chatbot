import numpy as np
import random
import sqlite3
import logging
from collections import defaultdict

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

class Entity:
    def __init__(self, name, action_space, state_space, db_path='entity_memory.db', config=None):
        self.name = name
        self.action_space = action_space
        self.state_space = state_space
        self.q_table = np.zeros((state_space, action_space))
        self.learning_rate = config.get('learning_rate', 0.1)
        self.discount_factor = config.get('discount_factor', 0.95)
        self.exploration_rate = config.get('exploration_rate', 1.0)
        self.exploration_decay = config.get('exploration_decay', 0.99)
        self.db_path = db_path
        self.math_understanding = defaultdict(float)
        self._init_db()
        self.load_q_table()
        self.load_math_understanding()

    def _init_db(self):
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS q_table (
                        subject TEXT,
                        state INTEGER,
                        action INTEGER,
                        value REAL,
                        PRIMARY KEY (subject, state, action)
                    )
                ''')
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS math_understanding (
                        subject TEXT PRIMARY KEY,
                        percentage REAL
                    )
                ''')
                conn.commit()
        except sqlite3.Error as e:
            logging.error(f"Database error: {e}")

    def _init_math_understanding(self):
        subjects = ["addition", "subtraction", "multiplication", "division"]
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                for subject in subjects:
                    cursor.execute('SELECT percentage FROM math_understanding WHERE subject = ?', (subject,))
                    row = cursor.fetchone()
                    if row is None:
                        cursor.execute('INSERT INTO math_understanding (subject, percentage) VALUES (?, ?)', (subject, 0.0))
                        self.math_understanding[subject] = 0.0
                    else:
                        self.math_understanding[subject] = row[0]
                conn.commit()
        except sqlite3.Error as e:
            logging.error(f"Database error: {e}")

    def save_math_understanding(self):
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.executemany('INSERT OR REPLACE INTO math_understanding (subject, percentage) VALUES (?, ?)',
                                   self.math_understanding.items())
                conn.commit()
        except sqlite3.Error as e:
            logging.error(f"Database error: {e}")

    def load_math_understanding(self):
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute('SELECT subject, percentage FROM math_understanding')
                self.math_understanding = {subject: percentage for subject, percentage in cursor.fetchall()}
        except sqlite3.Error as e:
            logging.error(f"Database error: {e}")

    def load_q_table(self):
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute('SELECT state, action, value FROM q_table WHERE subject = ?', (self.name,))
                for state, action, value in cursor.fetchall():
                    self.q_table[state, action] = value
        except sqlite3.Error as e:
            logging.error(f"Database error: {e}")

    def save_q_table(self):
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute('DELETE FROM q_table WHERE subject = ?', (self.name,))
                cursor.executemany('INSERT INTO q_table (subject, state, action, value) VALUES (?, ?, ?, ?)',
                                   [(self.name, state, action, self.q_table[state, action])
                                    for state in range(self.state_space) for action in range(self.action_space)])
                conn.commit()
        except sqlite3.Error as e:
            logging.error(f"Database error: {e}")

    def choose_action(self, state):
        return random.randint(0, self.action_space - 1) if random.random() < self.exploration_rate else np.argmax(self.q_table[state])

    def learn(self, state, action, reward, next_state):
        best_next_action = np.argmax(self.q_table[next_state])
        td_target = reward + self.discount_factor * self.q_table[next_state, best_next_action]
        td_error = td_target - self.q_table[state, action]
        self.q_table[state, action] += self.learning_rate * td_error
        self.save_q_table()

    def decay_exploration(self):
        self.exploration_rate = max(0.01, self.exploration_rate * self.exploration_decay)

    def __repr__(self):
        return f"Entity(name={self.name}, exploration_rate={self.exploration_rate})"