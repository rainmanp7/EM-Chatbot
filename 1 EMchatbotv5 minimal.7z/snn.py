import random
import logging
from collections import defaultdict, Counter
from typing import List, Dict, Tuple

# Configure logging (ensure consistency with the GrammarCorrector class)
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class Neuron:
    def __init__(self, threshold: float = 0.5, decay: float = 0.8):
        """
        Initialize a Neuron.
        
        :param threshold: Firing threshold for the neuron.
        :param decay: Potential decay factor.
        """
        self.potential: float = 0.0  # Current potential of the neuron
        self.threshold: float = threshold  # Threshold for spiking
        self.decay: float = decay  # Decay factor for potential
        self.last_spike_time: int = -1  # Last time the neuron spiked

    def integrate(self, input_spike: float, current_time: int) -> bool:
        """
        Integrate incoming spikes and determine if the neuron spikes.
        
        :param input_spike: Incoming spike value.
        :param current_time: Current time step.
        :return: True if the neuron spikes, False otherwise.
        """
        if not isinstance(input_spike, (int, float)):
            logger.error("Input spike must be a numeric value.")
            raise ValueError("Input spike must be a numeric value.")

        self.potential += input_spike
        if self.potential >= self.threshold:
            self.potential = 0.0  # Reset potential after spiking
            self.last_spike_time = current_time  # Update last spike time
            return True  # Neuron spiked
        
        self.potential *= self.decay  # Decay potential over time
        return False  # Neuron did not spike

class Synapse:
    def __init__(self, weight: float = 0.5, learning_rate: float = 0.01, stdp_rate: float = 0.1):
        """
        Initialize a Synapse.
        
        :param weight: Initial weight of the synapse.
        :param learning_rate: Rate for weight adjustments.
        :param stdp_rate: Spike-Timing-Dependent Plasticity (STDP) rate.
        """
        self.weight: float = weight  # Weight of the synapse
        self.learning_rate: float = learning_rate  # Learning rate for weight adjustment
        self.stdp_rate: float = stdp_rate  # STDP rate for weight adjustment based on timing
        self.last_used_time: int = -1  # Last time the synapse was used

    def transmit(self, spike: float) -> float:
        """
        Transmit a spike through the synapse.
        
        :param spike: Input spike value.
        :return: Transmitted spike value.
        """
        return self.weight if spike else 0

    def adjust_weight(self, pre_spike_time: int, post_spike_time: int) -> None:
        """
        Adjust synapse weight based on STDP rules.
        
        :param pre_spike_time: Time of the pre-synaptic spike.
        :param post_spike_time: Time of the post-synaptic spike.
        """
        if pre_spike_time != -1 and post_spike_time != -1:
            time_diff = post_spike_time - pre_spike_time
            
            # Log weight adjustment details
            logger.debug(f"Adjusting weight from {self.weight} by {self.stdp_rate * time_diff}.")
            self.weight += self.stdp_rate * time_diff  # Adjust weight based on timing difference
            
            # Ensure weight remains within reasonable bounds (e.g., [0, 1])
            self.weight = max(0.0, min(1.0, self.weight))
            self.last_used_time = max(pre_spike_time, post_spike_time)

class SpikingNeuralNetwork:
    def __init__(self):
        """
        Initialize the Spiking Neural Network.
        """
        self.neurons: List[Neuron] = []  # List of neurons in the network
        self.synapses: Dict[int, Dict[int, Synapse]] = defaultdict(dict)  # Dictionary to hold synapses between neurons
        self.current_time: int = 0  # Current time step in the simulation
        self.spike_history: Counter[int] = Counter()  # Track the number of spikes per time step

    def add_neuron(self) -> Neuron:
        """
        Add a new neuron to the network.
        
        :return: The newly added neuron.
        """
        neuron = Neuron()  # Create a new neuron instance
        self.neurons.append(neuron)  # Add it to the list of neurons
        logger.info(f"Added a new neuron. Total neurons: {len(self.neurons)}.")
        return neuron

    def step(self, inputs: List[float]) -> Dict[str, any]:
        """
        Process a time step with given inputs.
        
        :param inputs: List of input spike values.
        :return: Dictionary containing information about the step.
        """
        
        if not isinstance(inputs, list) or not all(isinstance(i, (int, float)) for i in inputs):
            logger.error("Inputs must be a list of numeric values.")
            raise ValueError("Inputs must be a list of numeric values.")

        spikes = []  # List to track spikes in this step

        # Ensure there are enough neurons for the inputs
        while len(self.neurons) < len(inputs):
            self.add_neuron()  # Add a new neuron if needed

        # Process inputs and update neurons
        for i, input_spike in enumerate(inputs):
            for j, neuron in enumerate(self.neurons):
                if j not in self.synapses[i]:
                    self.synapses[i][j] = Synapse(random.uniform(0.1, 1.0))  # Create a new synapse with random weight

                synapse = self.synapses[i][j]
                transmitted_spike = synapse.transmit(input_spike)  # Transmit input through synapse
                
                try:
                    spiked = neuron.integrate(transmitted_spike, self.current_time)  # Integrate spike in neuron
                except ValueError as e:
                    logger.error(f"Error integrating spike: {e}")
                    continue
                
                spikes.append(spiked)  # Record whether the neuron spiked
                self.spike_history[self.current_time] += int(spiked)  # Update spike history

                # Apply STDP if both pre- and post-synaptic neurons spiked
                if spiked and input_spike:
                    synapse.adjust_weight(self.current_time - 1, self.current_time)

        # Increment the current time step after processing inputs
        self.current_time += 1
        
        logger.info(f"Step completed at time {self.current_time}.")
        
        return {
            "any_spikes": any(spikes),
            "spikes": spikes,
            "current_time": self.current_time,
            "total_neurons": len(self.neurons),
            "total_synapses": sum(len(synapses) for synapses in self.synapses.values()),
            "spike_history": dict(self.spike_history)
        }

# Example usage
if __name__ == "__main__":
    network = SpikingNeuralNetwork()
    inputs = [random.random() for _ in range(5)]  # Example random input spikes
    output_info = network.step(inputs)
    print("Output information:", output_info)
