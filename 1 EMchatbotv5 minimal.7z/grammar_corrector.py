import re
from collections import Counter
import logging
from typing import Tuple, List

# Configure Logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


class GrammarCorrector:
    def __init__(self, frequency_dict_path: str = "frequency_dictionary.txt"):
        self.corrections: List[Tuple[str, str]] = [
            (r'\bwhat is\b', 'What is'),
            (r'\bwho is\b', 'Who is'),
            (r'\bpython\b', 'Python'),
            (r'\bi\b', 'I'),
            (r'\byoure\b', "you're"),
            (r'\bdont\b', "don't"),
            (r'\bdoesnt\b', "doesn't"),
            (r'\bdidnt\b', "didn't"),
            (r'\bwont\b', "won't"),
            (r'\bcant\b', "can't"),
            (r'\bits\b', "it's"),
            (r'\btheres\b', "there's"),
            (r'\btheyre\b', "they're"),
            (r'\bwere\b', "we're"),
            (r'\bhes\b', "he's"),
            (r'\bshes\b', "she's"),
            (r'\bisnt\b', "isn't"),
            (r'\barent\b', "aren't"),
            (r'\bwasnt\b', "wasn't"),
            (r'\bwerent\b', "weren't"),
            (r'\bhasnt\b', "hasn't"),
            (r'\bhavent\b', "haven't"),
            (r'\bhadnt\b', "hadn't"),
            (r'\bcouldnt\b', "couldn't"),
            (r'\bwouldnt\b', "wouldn't"),
            (r'\bshouldnt\b', "shouldn't"),
            (r'\bmightnt\b', "mightn't"),
            (r'\bmustnt\b', "mustn't"),
            (r'\bwhats\b', "what's")
        ]
        self.frequency_dict_path = frequency_dict_path
        self.frequency_dict: Counter[str] = self.load_frequency_dictionary()
        self.updated = False

        # Spiking Neural Network (Assuming this is implemented elsewhere)
        self.snn = None

    def load_frequency_dictionary(self) -> Counter[str]:
        """Load the frequency dictionary from a file."""
        try:
            with open(self.frequency_dict_path, 'r', encoding='utf-8') as file:
                frequency_dict = Counter()
                for line in file:
                    try:
                        word, freq = line.strip().split()
                        frequency_dict[word] = int(freq)
                    except ValueError:
                        logger.warning(f"Malformed line in frequency dictionary: {line.strip()}")
                return frequency_dict
        except FileNotFoundError:
            logger.info(f"Frequency dictionary file not found at {self.frequency_dict_path}. Initializing empty.")
            return Counter()

    def save_frequency_dictionary(self):
        """Save the updated frequency dictionary to a file."""
        if self.updated:
            with open(self.frequency_dict_path, 'w', encoding='utf-8') as file:
                for word, freq in self.frequency_dict.most_common():
                    file.write(f"{word} {freq}\n")
            self.updated = False

    def update_frequency(self, word: str):
        """Update the frequency of a word in the dictionary."""
        word = word.lower()
        self.frequency_dict[word] += 1
        self.updated = True

    def generate_deletes(self, word: str, max_distance: int = 2) -> set[str]:
        """Generate all possible deletions of a word up to a maximum distance."""
        if max_distance < 1:
            raise ValueError("max_distance must be a positive integer")

        deletes = {word}
        for _ in range(max_distance):
            temp_deletes = set()
            for delete in deletes:
                for i in range(len(delete)):
                    temp_deletes.add(delete[:i] + delete[i+1:])
            deletes = temp_deletes  # Replace deletes with the newly generated deletions

        return deletes

    def spell_correct(self, word: str, max_distance: int = 2) -> str:
        """Correct the spelling of a word using the frequency dictionary."""
        if word in self.frequency_dict:
            return word
        deletes = self.generate_deletes(word, max_distance)
        candidates = {delete for delete in deletes if delete in self.frequency_dict}
        if candidates:
            return max(candidates, key=self.frequency_dict.get)
        return word

    def correct_grammar(self, text: str) -> str:
        """Correct grammar and spelling in the input text."""
        original_text = text
        text = text.lower()
        corrected_words = []
        for i, word in enumerate(text.split()):
            # Apply rule-based corrections 
            for pattern, replacement in self.corrections:
                word = re.sub(pattern, replacement, word, flags=re.IGNORECASE) 

            # Apply spell correction after rule-based corrections
            corrected_word = self.spell_correct(word) 

            if original_text.split()[i][0].isupper() and corrected_word[0].islower():
                corrected_word = corrected_word.capitalize()
            corrected_words.append(corrected_word)
            self.update_frequency(corrected_word.lower())
        text = ' '.join(corrected_words)
        if not text.endswith(('.', '!', '?')):
            text += '.'
        self.save_frequency_dictionary()
        return text

# Example Usage
if __name__ == "__main__":
    corrector = GrammarCorrector()
    original_text = "whats youre name? dont forget to tell me."
    corrected_text = corrector.correct_grammar(original_text)
    print(f"Original Text: {original_text}")
    print(f"Corrected Text: {corrected_text}")
