from entity import Entity
from environment import MathEnvironment
import matplotlib.pyplot as plt

def train_entity(subject, plot_rewards=False):
    """
    Train the Entity on a specific math subject.
    
    Args:
        subject (str): The math subject to train on (e.g., "addition", "subtraction").
        plot_rewards (bool): Whether to plot the rewards after training.
    """
    state_space = 5  # Number of possible states
    action_space = 5  # Number of possible actions
    episodes = 100  # Number of training episodes

    # Initialize the entity and environment
    config = {
        'learning_rate': 0.1,
        'discount_factor': 0.95,
        'exploration_rate': 1.0,
        'exploration_decay': 0.99
    }
    entity = Entity("AI_Entity", action_space, state_space, config=config)
    env = MathEnvironment(state_space, action_space)

    # Load the Q-table and math understanding for the subject
    entity.load_q_table()
    entity.load_math_understanding()

    # List to store rewards for each episode
    rewards = []

    # Training loop
    for episode in range(episodes):
        state = env.reset()  # Reset the environment to an initial state
        total_reward = 0

        for step in range(20):  # Limit the number of steps per episode
            # Generate a math problem based on the subject
            problem, correct_answer, possible_answers = env.generate_math_problem(subject)
            
            # The entity chooses an action (index of the chosen answer)
            action = entity.choose_action(state)
            
            # Get the chosen answer based on the action
            chosen_answer = possible_answers[action]
            
            # Calculate the reward based on whether the chosen answer is correct
            reward = env.get_reward(chosen_answer, correct_answer)
            
            # Determine the next state (for simplicity, use a fixed transition)
            next_state = env.next_state(state, action)
            
            # Update the Q-table using the Q-learning formula
            entity.learn(state, action, reward, next_state)
            
            # Update the state and total reward
            state = next_state
            total_reward += reward

            # End the episode early if the entity gets a correct answer
            if reward > 0:
                break

        # Decay the exploration rate after each episode
        entity.decay_exploration()
        
        # Store the total reward for this episode
        rewards.append(total_reward)
        
        # Print the episode results
        print(f"Episode {episode + 1}: Total Reward = {total_reward}")

    # Save the Q-table and math understanding for the subject
    entity.save_q_table()
    entity.save_math_understanding()

    # Calculate and update the math understanding percentage
    correct_answers = sum(1 for reward in rewards if reward > 0)
    total_answers = len(rewards)
    understanding_percentage = (correct_answers / total_answers) * 100
    entity.math_understanding[subject] = understanding_percentage
    entity.save_math_understanding()

    # Print the final results
    print(f"Training complete. Final Q-Table for {subject}:")
    print(entity.q_table)
    print(f"Understanding of {subject}: {understanding_percentage:.2f}%")

    # Plot rewards over episodes if plot_rewards is True
    if plot_rewards:
        plt.plot(rewards)
        plt.title(f"Training Rewards Over Episodes ({subject})")
        plt.xlabel("Episode")
        plt.ylabel("Total Reward")
        plt.show()

if __name__ == "__main__":
    # Example: Train on addition
    train_entity(subject="addition", plot_rewards=True)